import { Mail, MapPin, Phone } from "lucide-react";

export default function Contact() {
  // =====================================================
  // YOUR CONTACT INFORMATION
  // Replace these with your real details.
  // =====================================================
  const email = "yourname@example.com";
  const phone = "+234 800 000 0000";
  const location = "Akwa Ibom, Nigeria";

  return (
    <section id="contact" className="section">
      <div className="section-container">
        <div className="contact-container">
          <div className="contact-text">
            <p className="section-label">CONTACT</p>

            <h2>
              Let's build something <span>together.</span>
            </h2>

            <p>
              Have a project, opportunity or question? Feel free to reach out.
            </p>
          </div>

          <div className="contact-info">
            <a href={`mailto:${email}`} className="contact-item">
              <div>
                <Mail />
              </div>
              <span>{email}</span>
            </a>

            <a href={`tel:${phone}`} className="contact-item">
              <div>
                <Phone />
              </div>
              <span>{phone}</span>
            </a>

            <div className="contact-item">
              <div>
                <MapPin />
              </div>
              <span>{location}</span>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
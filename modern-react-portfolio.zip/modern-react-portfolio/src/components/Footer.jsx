export default function Footer() {
  const year = new Date().getFullYear();

  // Change the name below if necessary.
  return (
    <footer className="footer">
      <div className="footer-container">
        <strong>
          Bstar Ime<span>.</span>
        </strong>

        <p>© {year} Bstar Ime. All rights reserved.</p>
      </div>
    </footer>
  );
}
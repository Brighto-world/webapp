import { ExternalLink, Github } from "lucide-react";

export default function Projects() {
  // =====================================================
  // YOUR PROJECTS
  //
  // Add your own projects to this array.
  // Each project needs:
  // title, description, technologies, github and demo.
  // =====================================================
  const projects = [
    {
      title: "E-Banking Platform",
      description:
        "A modern banking interface designed to provide users with a clean and intuitive way to manage their finances.",
      technologies: ["React", "JavaScript", "CSS"],
      github: "https://github.com/yourusername/banking-project",
      demo: "https://your-demo.com",
    },
    {
      title: "Developer Portfolio",
      description:
        "A responsive personal portfolio website showcasing skills, projects, education and professional growth.",
      technologies: ["React", "CSS", "Vite"],
      github: "https://github.com/yourusername/portfolio",
      demo: "https://yourportfolio.com",
    },
    {
      title: "Student Management System",
      description:
        "A system designed to manage student records and organize academic information.",
      technologies: ["Java", "MySQL"],
      github: "https://github.com/yourusername/student-system",
      demo: "#",
    },
  ];

  return (
    <section id="projects" className="section">
      <div className="section-container">
        <div className="section-heading">
          <p className="section-label">PORTFOLIO</p>
          <h2>
            Some of my <span>projects.</span>
          </h2>
        </div>

        <div className="projects-grid">
          {projects.map((project) => (
            <article className="project-card" key={project.title}>
              <div className="project-preview">
                <span>PROJECT</span>
              </div>

              <div className="project-content">
                <h3>{project.title}</h3>
                <p>{project.description}</p>

                <div className="project-tech">
                  {project.technologies.map((technology) => (
                    <span key={technology}>{technology}</span>
                  ))}
                </div>

                <div className="project-links">
                  <a
                    href={project.github}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <Github size={17} />
                    Code
                  </a>

                  <a
                    href={project.demo}
                    target="_blank"
                    rel="noreferrer"
                  >
                    <ExternalLink size={17} />
                    Live Demo
                  </a>
                </div>
              </div>
            </article>
          ))}
        </div>
      </div>
    </section>
  );
}
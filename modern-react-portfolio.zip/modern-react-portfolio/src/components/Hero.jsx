import { ArrowDown, Github, Linkedin, Mail } from "lucide-react";

export default function Hero() {
  // =====================================================
  // PERSONAL DETAILS — EDIT THESE VALUES
  // =====================================================
  const firstName = "Bstar";
  const lastName = "Ime";
  const role = "Computer Science Student & Aspiring Software Developer";
  const introduction =
    "I build modern, responsive and user-focused digital experiences while continuously improving my software development skills.";

  // Replace these with your real social links.
  const github = "https://github.com/yourusername";
  const linkedin = "https://linkedin.com/in/yourusername";
  const email = "mailto:yourname@example.com";

  return (
    <section id="home" className="hero">
      <div className="hero-container">
        <div className="hero-content">
          <p className="hero-label">HELLO, I'M</p>

          <h1>
            {firstName}
            <br />
            <span>{lastName}</span>
          </h1>

          <h2>{role}</h2>

          <p className="hero-description">{introduction}</p>

          <div className="hero-buttons">
            <a href="#projects" className="btn btn-primary">
              View My Work
            </a>
            <a href="#contact" className="btn btn-outline">
              Contact Me
            </a>
          </div>

          <div className="social-links">
            <a href={github} target="_blank" rel="noreferrer" aria-label="GitHub">
              <Github size={20} />
            </a>
            <a
              href={linkedin}
              target="_blank"
              rel="noreferrer"
              aria-label="LinkedIn"
            >
              <Linkedin size={20} />
            </a>
            <a href={email} aria-label="Email">
              <Mail size={20} />
            </a>
          </div>
        </div>

        <div className="hero-image-container">
          <div className="hero-image-decoration" />

          {/* Put your own image at public/profile.jpg */}
          <img
            src="/profile.jpg"
            alt="Profile"
            className="hero-image"
            onError={(event) => {
              event.currentTarget.style.visibility = "hidden";
            }}
          />
        </div>
      </div>

      <a href="#about" className="scroll-indicator" aria-label="Scroll to About">
        <ArrowDown size={18} />
      </a>
    </section>
  );
}
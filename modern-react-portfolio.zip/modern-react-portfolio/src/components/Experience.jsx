export default function Experience() {
  // =====================================================
  // YOUR EDUCATION / EXPERIENCE
  // Add more objects to this array when needed.
  // =====================================================
  const timeline = [
    {
      year: "2025 - Present",
      title: "Computer Science Student",
      organization: "Akwa Ibom State University",
      description:
        "Studying computer science with a focus on programming, computer architecture, data structures, networking and software development.",
    },
    {
      year: "2026",
      title: "Web Development",
      organization: "Personal Projects",
      description:
        "Building responsive websites and applications using modern web technologies.",
    },
  ];

  return (
    <section id="experience" className="section section-alt">
      <div className="section-container">
        <div className="section-heading">
          <p className="section-label">MY JOURNEY</p>
          <h2>
            Education & <span>experience.</span>
          </h2>
        </div>

        <div className="timeline">
          {timeline.map((item) => (
            <div
              className="timeline-item"
              key={`${item.year}-${item.title}`}
            >
              <div className="timeline-dot" />

              <div className="timeline-content">
                <span className="timeline-year">{item.year}</span>
                <h3>{item.title}</h3>
                <h4>{item.organization}</h4>
                <p>{item.description}</p>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
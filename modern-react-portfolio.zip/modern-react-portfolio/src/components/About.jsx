import { Code2, GraduationCap, Target } from "lucide-react";

export default function About() {
  // =====================================================
  // WRITE YOUR PERSONAL BIOGRAPHY HERE
  // =====================================================
  const aboutText =
    "I am a Computer Science student passionate about technology, software development and cybersecurity. I enjoy understanding how computers work and turning ideas into practical digital solutions.";

  const secondParagraph =
    "My goal is to continuously improve my technical skills, build meaningful projects and contribute to innovative technology products.";

  return (
    <section id="about" className="section">
      <div className="section-container">
        <div className="section-heading">
          <p className="section-label">ABOUT ME</p>
          <h2>
            Turning curiosity into <span>technology.</span>
          </h2>
        </div>

        <div className="about-grid">
          <div className="about-text">
            <p>{aboutText}</p>
            <p>{secondParagraph}</p>
          </div>

          <div className="about-cards">
            <AboutCard
              icon={<GraduationCap />}
              title="Education"
              value="B.Sc. Computer Science"
              detail="Akwa Ibom State University"
            />

            <AboutCard
              icon={<Code2 />}
              title="Focus"
              value="Software Development"
              detail="Web & Backend Development"
            />

            <AboutCard
              icon={<Target />}
              title="Goal"
              value="Become a Professional Developer"
              detail="Building useful technology"
            />
          </div>
        </div>
      </div>
    </section>
  );
}

function AboutCard({ icon, title, value, detail }) {
  return (
    <div className="about-card">
      <div className="about-icon">{icon}</div>
      <div>
        <h3>{title}</h3>
        <p>{value}</p>
        <small>{detail}</small>
      </div>
    </div>
  );
}
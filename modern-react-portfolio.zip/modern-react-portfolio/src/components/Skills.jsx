export default function Skills() {
  // =====================================================
  // ADD, REMOVE OR CHANGE YOUR SKILLS HERE
  // =====================================================
  const groups = [
    {
      title: "Frontend Development",
      skills: ["HTML", "CSS", "JavaScript", "React", "Responsive Design"],
    },
    {
      title: "Programming",
      skills: ["Python", "Java", "C++", "Data Structures"],
    },
    {
      title: "Tools & Technologies",
      skills: ["Git", "GitHub", "Linux", "VS Code", "Figma"],
    },
  ];

  return (
    <section id="skills" className="section section-alt">
      <div className="section-container">
        <div className="section-heading">
          <p className="section-label">MY SKILLS</p>
          <h2>
            Technologies I <span>work with.</span>
          </h2>
        </div>

        <div className="skills-grid">
          {groups.map((group) => (
            <div className="skill-group" key={group.title}>
              <h3>{group.title}</h3>

              <div className="skill-list">
                {group.skills.map((skill) => (
                  <span className="skill" key={skill}>
                    {skill}
                  </span>
                ))}
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
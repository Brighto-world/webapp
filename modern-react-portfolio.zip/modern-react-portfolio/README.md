# Modern React Portfolio

A responsive personal portfolio built with React, Vite and Lucide React.

## Requirements

- Node.js 18+ recommended
- npm

## Install

```bash
npm install
```

## Run locally

```bash
npm run dev
```

## Production build

```bash
npm run build
```

## Preview production build

```bash
npm run preview
```

## Where to customize

Most personal information has comments in the source files.

- `src/components/Hero.jsx` — name, title, introduction and social links
- `src/components/About.jsx` — biography, education and goals
- `src/components/Skills.jsx` — skills
- `src/components/Projects.jsx` — projects, GitHub and demo links
- `src/components/Experience.jsx` — education and experience
- `src/components/Contact.jsx` — email, phone and location
- `src/components/Footer.jsx` — footer name
- `public/profile.jpg` — profile photo

## Profile photo

Replace `public/profile.jpg` with your own photo. Keep the filename `profile.jpg`, or update the image path in `Hero.jsx`.

## Theme

The portfolio supports light and dark themes. The selected theme is stored in `localStorage`, so it remains after a page refresh.

## Notes

The project intentionally contains sample placeholder personal information. Replace it before publishing the portfolio.
